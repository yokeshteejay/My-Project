import React from "react";

import "./hair.css";
import Formpage from "./formpage";


function Main() {
  return (
    <div className="App">
     <Formpage/>
    </div>
  );
}

export default Main;
